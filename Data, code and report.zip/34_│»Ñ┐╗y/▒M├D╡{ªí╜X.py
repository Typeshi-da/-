import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
df = pd.read_csv(r'C:\Users\student\Desktop\食品業者登錄資料集.csv')
df_population = pd.read_csv('鄉鎮土地面積及人口密度(至113年底).csv', encoding='utf-8')
#note:修改DataFrame完先執行to_csv函數保存檔案，這樣才能覆蓋原始檔案，否則下次運行時檔案還是修改過之前的
df_population.to_csv('鄉鎮土地面積及人口密度(至113年底).csv', index=False, encoding='utf-8')
# 問題:
# 哪些縣市的手搖飲店「總數」最多？
# 各縣市的「人口密度」與「手搖飲店密度」狀況（每萬人/每平方公里有多少家店）
# 六都與非六都的店家數占比?(可以看出這個產業的地理集中程度)

# 問題一：哪些縣市的手搖飲店「總數」最多？

# 從「名稱」過濾：建立一份包含常見手搖飲品牌的列表 #note:使用deepseek請它查詢台灣手搖/飲料品牌資料加上自身google資料整合而成, 資料:https://blog.104.com.tw/taiwan-beverage-industry/#01
bubble_tea_keywords = ['五十嵐', '清心福全', '清心', 'coco', 'coco都可', '茶湯會', '迷客夏', 
    '大苑子', '可不可', '可不可熟成紅茶', '麻古', '麻古茶坊', '珍煮丹', 
    '一芳', '一芳水果茶', '貢茶', '鮮茶道', 'comebuy', '水雲堂', '龜記',
    '萬波', '萬波島嶼', '歇腳亭', 'sipship', 'tp tea', '德傳茶', '老賴', 
    '老賴茶棧', '鬍子茶', '木衛二', '京盛宇', '烏弄', '八曜和茶', '得正', 
    '布萊恩', '布萊恩紅茶', '圓石', '圓石禪飲', '好了啦', 'cupa', '老虎堂',
    '幸福堂', '署茗職茶', '不要對我尖叫', '白巷子', '花甜果室', '春陽茶事',
    '十三月', '十三漁', '哞哞屋', '良辰吉時', '約翰紅茶', '約翰紅茶公司', 
    '五桐號', '可蜜達', '糖奶奶', '紅太陽', '舞鶴', '茶之魔手', '阿義', 
    '阿義茶飲', '黃家紅茶冰', '小雅', '小雅茶舖', '龍泉', '甘蔗媽媽'
    'Soma', 'teatop', '台灣第一味', '一手私藏世界紅茶', '一手私藏', '一沐日', 
    '上宇林', '先喝道', '再睡五分鐘', '初韻', '功夫茶', '叮哥', '喫茶小舖', 
    '坪林手', '大茗', '天仁茶業', '天仁', '喫茶趣', '小職人', '山焙', 
    '康青龍', '拾汣茶屋', '日出茶太', '日日裝茶', '春芳號', '有飲', '樂法', 
    '樺達奶茶', '武林茶', '水巷茶弄', '泰讚了', '無飲', '發發', '茶奶士多', 
    '茶的魔手', '茶聚', '魚池貳壹', '鶴茶樓', '麥吉', '龍角', '飲料', '茶飲', 
    '茗茶', '手搖', '茶坊', '茶業', '茶專賣', '紅茶', '綠茶', '奶茶', '珍奶', '波霸'
]

# 建立一個布林遮罩，判斷店名是否包含任何一個關鍵字 
mask = df['公司或商業登記名稱'].str.contains('|'.join(bubble_tea_keywords), na=False, case=False)

# 應用遮罩，得到手搖飲店的資料
bubble_tea_df = df[mask].copy()
print(bubble_tea_df)

# 從「地址」統一歸類到「縣市」
bubble_tea_df['縣市'] = bubble_tea_df['業者地址'].str.extract(r'(^.{2,3}[市縣])')

print(f"總共過濾出 {len(bubble_tea_df)} 家手搖飲店")

# 計算每個縣市有幾家店
shop_count_by_city = bubble_tea_df['縣市'].value_counts().reset_index()
shop_count_by_city.columns = ['縣市', '店家總數']

# 合併店家數與人口面積資料 #note:欄位,key值的名稱都要一模一樣才合併的起來
merged_df = pd.merge(shop_count_by_city, df_population, on='縣市', how='outer')
merged_df = pd.read_csv('合併店家數與人口面積資料.csv', encoding='utf-8')
columns_to_clean = ['人口數', '土地面積', '人口密度']
for col in columns_to_clean:
    if col in merged_df.columns:
        # 移除逗點後轉為數值
        merged_df[col] = pd.to_numeric(
            merged_df[col].astype(str).str.replace(',', ''), 
            errors='coerce'
        )

# 計算密度
merged_df['店家密度_每萬人'] = (merged_df['店家總數'] / merged_df['人口數']) * 10000
merged_df['店家密度_每平方公里'] = merged_df['店家總數'] / merged_df['土地面積']

# 設定中文字體
plt.rcParams['font.sans-serif'] = ['Microsoft JhengHei']  # 或 SimHei
plt.rcParams['axes.unicode_minus'] = False

plt.figure(figsize=(12, 8))
# 長條圖
plt.subplot(1, 1, 1)
top_10_by_count = merged_df.nlargest(10, '店家總數')

# 排序：讓最多的在最左或最右（依喜好）
top_10_by_count = top_10_by_count.sort_values('店家總數', ascending=False)

# 自訂顏色：前6名橙色，其餘灰色
colors = ['orange' if i < 6 else 'gray' for i in range(len(top_10_by_count))]

# 畫圖：縣市在 X 軸、店家總數在 Y 軸
ax = sns.barplot(data=top_10_by_count, x='縣市', y='店家總數', palette=colors)

# 標題與標籤
plt.title('手搖飲店數前十名縣市', fontsize=18, fontweight='bold')
plt.ylabel('店\n家\n數\n量', rotation=0, ha='center', va='center',  labelpad=10)
plt.xlabel('縣市', fontsize=15)

# 在長條頂端標出數字
for p in ax.patches:
    ax.text(
        p.get_x() + p.get_width() / 2,       # X 座標：長條中央
        p.get_height() + max(top_10_by_count['店家總數']) * 0.01,  # Y 座標：略高於長條頂端
        int(p.get_height()),                 # 顯示的文字：店家數量
        ha='center', va='bottom', fontsize=10
    )

# 讓 X 軸縣市名稱旋轉以避免重疊
plt.xticks(rotation=45)

plt.tight_layout()
plt.show()

# 問題二：哪些縣市的「人口密度」與「手搖飲店密度」最高？（每萬人/每平方公里有多少家店）

plt.rcParams['axes.unicode_minus'] = False # 解決負號顯示問題

# 計算中位數，用於劃分四象限
pop_density_median = merged_df['人口密度'].median()
shop_density_median = merged_df['店家密度_每平方公里'].median()
print(f"人口密度中位數: {pop_density_median:.2f} 人/平方公里")
print(f"手搖飲店密度中位數: {shop_density_median:.2f} 店/平方公里")

# 繪製所有縣市的散點圖（統一顏色）
plt.figure(figsize=(14, 10))
plt.scatter(merged_df['人口密度'], merged_df['店家密度_每平方公里'], 
           color='steelblue', s=120, alpha=0.7, edgecolors='black', linewidth=0.8)

# 為每個點添加縣市標籤
for i, row in merged_df.iterrows():
    plt.annotate(row['縣市'], 
                (row['人口密度'], row['店家密度_每平方公里']),
                xytext=(8, 8), 
                textcoords='offset points', 
                fontsize=10,
                fontweight='bold',
                color='darkblue',
                alpha=0.8)
    
# 繪製四象限的分隔線
plt.axvline(x=pop_density_median, color='red', linestyle='--', alpha=0.7, 
            label=f'人口密度中位數: {pop_density_median:.1f}')
plt.axhline(y=shop_density_median, color='red', linestyle='--', alpha=0.7, 
            label=f'手搖飲店密度中位數: {shop_density_median:.1f}')

# 添加四象限標籤
plt.text(pop_density_median * 1.7, shop_density_median * 1.7, '核心戰區\n(高人口, 高店數)', 
         fontsize=13, color='darkred', ha='center', va='center', 
         bbox=dict(boxstyle="round,pad=0.3", facecolor='red', alpha=0.2))
plt.text(pop_density_median * 0.3, shop_density_median * 1.7, '特殊需求區\n(低人口, 高店數)', 
         fontsize=13, color='darkblue', ha='center', va='center',
         bbox=dict(boxstyle="round,pad=0.3", facecolor='blue', alpha=0.2))
plt.text(pop_density_median * 1.7, shop_density_median * 0.3, '潛力成長區\n(高人口, 低店數)', 
         fontsize=13, color='darkgreen', ha='center', va='center',
         bbox=dict(boxstyle="round,pad=0.3", facecolor='green', alpha=0.2))
plt.text(pop_density_median * 0.3, shop_density_median * 0.3, '低度開發區\n(低人口, 低店數)', 
         fontsize=13, color='darkorange', ha='center', va='center',
         bbox=dict(boxstyle="round,pad=0.3", facecolor='orange', alpha=0.2))

# 設定圖表標題和標籤
plt.title('台灣各縣市人口密度 x 手搖飲店密度四象限分析', fontsize=16, fontweight='bold', pad=20)
plt.xlabel('人口密度 (人/平方公里)', fontsize=12)
plt.ylabel('手搖飲店密度 (店/平方公里)', fontsize=12)

# 設定對數尺度（讓數據分布更清晰）
plt.xscale('log')
plt.yscale('log')

# 添加網格和圖例
plt.grid(True, alpha=0.3)
plt.legend()

# 調整布局並顯示
plt.tight_layout()
plt.show()




# 問題三:六都與非六都的分布有何差異？
# 這題使用power bi進行視覺化 使用merged_df的資料
# 核心的要點在於新增兩個資料行(區域分類、全台總店數)用於製作比例圖
# 區域分類分出六都與非六都
# 全台總店數用於計算比例

# 問題四:手搖飲店的分布與哪些其他社會或商業經濟指標有關？#資料都是113年的

# 建立完整的分析資料框架
analysis_df = merged_df[['縣市', '店家總數', '店家密度_每萬人', '店家密度_每平方公里', '人口密度', '土地面積']].copy()
# 新增資料
other_data = {
    '縣市': ['台北市', '新北市', '桃園市', '台中市', '台南市', '高雄市', 
           '宜蘭縣', '新竹縣', '苗栗縣', '彰化縣', '南投縣', '雲林縣', 
           '嘉義縣', '屏東縣', '台東縣', '花蓮縣', '澎湖縣', '基隆市', 
           '新竹市', '嘉義市'],
    
    '人均可支配所得_萬元': [47.1, 39.4, 35.5, 34.4, 30.5, 33.9, 
                        31.0, 36.6, 31.4, 29.8, 29.9, 30.3, 
                        29.3, 29.2, 28.4, 31.5, 32.2, 32.3, 
                        40.9, 34.8],
    
    '商業區面積(公頃)': [831, 868, 821, 1047, 765, 1574, 
                        178, 158, 168, 345, 172, 246, 
                        185, 244, 103, 210, 37, 118, 
                        188, 200],
}
    
other_data_df = pd.DataFrame(other_data)
analysis_df = pd.merge(analysis_df, other_data_df, on='縣市', how='left')













